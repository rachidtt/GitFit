package com.donovan.fitnessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import static com.donovan.fitnessapp.R.layout.body_info_layout;

/**
 * Created by stoic on 12/4/2017.
 */

public class body_info /* next part needed for setContentView*/extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(body_info_layout);
    }

}


