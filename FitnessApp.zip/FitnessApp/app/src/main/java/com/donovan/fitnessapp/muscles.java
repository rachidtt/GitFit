package com.donovan.fitnessapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import static com.donovan.fitnessapp.R.layout.muscles;

/**
 * Created by stoic on 12/6/2017.
 */

public class muscles extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(muscles);
    }
}
